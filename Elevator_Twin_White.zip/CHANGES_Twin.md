# Twin Lift Control Room - what changed (from Elevator_with_time_FIXED)

## Build status
NOT built with the real .NET 10 / Windows Desktop toolchain (not available where this was prepared).
Checked instead: a full compile of all sources against Mono's WinForms/System.Drawing (0 errors; LogRepository.cs and
Program.cs replaced by a stub for that check only), a rendered picture of the window, and a run of the real model with
BOTH lifts at the same time (8 checks, all passed): A and B move in opposite directions at once, arrive correctly,
an emergency stop on A and an overload on B do not affect each other, an overloaded lift refuses to move, both lifts write
their own log entries and the log filter shows exactly each lift's entries, the window closes cleanly.
NOT checked: the real Visual Studio build, the MySQL connection, Design view, your screen DPI.

## Second lift
- New LiftUnit.cs + LiftUnit.Designer.cs (UserControl): one complete lift = shaft + control card + its own
  Elevator model, timer, alarm timer and database observer. The code of the old Form1 (RefreshView, buttons, alarm) moved there.
- The window has two of them: liftA ("Lift A", starts on G) and liftB ("Lift B", starts on floor 1, Mirrored = true).
- Elevator.cs, ElevatorStates.cs, ElevatorController.cs, LogRepository.cs, Program.cs, dbsettings.json: unchanged
  (only "namespace Elevator_with_time" -> "Elevator_Twin"). The model already had a Name and no static state, so two instances just work.
- Log: the Elevator column now shows "Lift A" / "Lift B" (database table unchanged; the name fits VARCHAR(20)).

## New UI (everything in a different place)
- Header bar on top: title, clock, log filter (All lifts / Lift A / Lift B), Show Log, Clear Log, Exit.
- Middle row: Lift A control card | Lift A shaft | Lift B shaft | Lift B control card (the old layout was shaft | panel | log).
- Event log is now full width at the bottom (was a right-hand column), DB status under it.
- Inside each card: title + floor LED + compact status list on top, FLOOR buttons as a vertical car panel (1 above G)
  with MOVE and DOOR in columns beside them, SAFETY row, and a new LOAD row (-100 / +100 kg) for the overload sensor
  the model already had but the old panel never showed ("OVERLOAD - REDUCE LOAD" message, amber).
- New look: Theme.cs = "Emerald Control Room" (dark green metal, mint LED text, gold accent, dark green granite).
  New CardPanel control (flat rounded dark card with a gold top strip) replaces the brushed-steel panel; section captions use a thin gold line.
  Controls.cs: hard-coded greys of the shaft (hoistway, fascia, floor, slab) moved into the theme; button text uses new theme
  colours (light text on dark metal, LitInk, DisabledInk); call-button arrows use CapInk.
- Form1.Designer.cs and LiftUnit.Designer.cs are in standard designer form (no loops, no helper methods).
  Hidden properties (Tint, TextColor, Tag, Caption) are set in the LiftUnit constructor, as before.

## Files
Folder, .sln, .csproj and RootNamespace renamed to Elevator_Twin (new project GUID). The zip contains no .vs, bin or obj folders.
Your dbsettings.json is included unchanged (it holds your MySQL password: do not share the zip).
