namespace Elevator_Twin
{
    partial class LiftUnit
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        private void InitializeComponent()
        {
            shaft = new ElevatorShaft();
            pnlPanel = new CardPanel();
            lblTitle = new Label();
            ledFloor = new LedDisplay();
            pnlInfo = new DisplayPanel();
            lblCurrentFloor = new Label();
            lblDestination = new Label();
            lblDirection = new Label();
            lblInnerDoor = new Label();
            lblOuterDoor = new Label();
            lblDoor = new Label();
            lblStatus = new Label();
            lblQueue = new Label();
            lblMessage = new DisplayLabel();
            lblEmergencyLamp = new DisplayLabel();
            lblAlarmLamp = new DisplayLabel();
            lblInterlockLamp = new DisplayLabel();
            lblFloorCaption = new SectionLabel();
            lblMovementCaption = new SectionLabel();
            lblDoorCaption = new SectionLabel();
            btnFloor1 = new SteelButton();
            btnUp = new SteelButton();
            btnOpenDoor = new SteelButton();
            btnFloorG = new SteelButton();
            btnDown = new SteelButton();
            btnCloseDoor = new SteelButton();
            lblSafetyCaption = new SectionLabel();
            btnEmergency = new SteelButton();
            btnAlarm = new SteelButton();
            btnReset = new SteelButton();
            btnLoadMinus = new SteelButton();
            lblLoad = new DisplayLabel();
            btnLoadPlus = new SteelButton();
            pnlPanel.SuspendLayout();
            pnlInfo.SuspendLayout();
            SuspendLayout();
            // 
            // shaft
            // 
            shaft.Location = new Point(360, 0);
            shaft.Name = "shaft";
            shaft.Size = new Size(340, 520);
            shaft.TabIndex = 0;
            // 
            // lblTitle
            // 
            lblTitle.BackColor = Color.Transparent;
            lblTitle.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitle.ForeColor = Color.FromArgb(224, 130, 0);
            lblTitle.Location = new Point(14, 12);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(220, 34);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "LIFT";
            lblTitle.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // ledFloor
            // 
            ledFloor.Location = new Point(12, 54);
            ledFloor.Name = "ledFloor";
            ledFloor.Size = new Size(96, 118);
            ledFloor.TabIndex = 1;
            // 
            // lblCurrentFloor
            // 
            lblCurrentFloor.BackColor = Color.Transparent;
            lblCurrentFloor.Font = new Font("Consolas", 8.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCurrentFloor.ForeColor = Color.FromArgb(0, 96, 148);
            lblCurrentFloor.Location = new Point(6, 3);
            lblCurrentFloor.Name = "lblCurrentFloor";
            lblCurrentFloor.Size = new Size(212, 14);
            lblCurrentFloor.TabIndex = 0;
            lblCurrentFloor.Text = "Floor : G";
            lblCurrentFloor.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblDestination
            // 
            lblDestination.BackColor = Color.Transparent;
            lblDestination.Font = new Font("Consolas", 8.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDestination.ForeColor = Color.FromArgb(0, 96, 148);
            lblDestination.Location = new Point(6, 17);
            lblDestination.Name = "lblDestination";
            lblDestination.Size = new Size(212, 14);
            lblDestination.TabIndex = 1;
            lblDestination.Text = "Dest  : -";
            lblDestination.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblDirection
            // 
            lblDirection.BackColor = Color.Transparent;
            lblDirection.Font = new Font("Consolas", 8.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDirection.ForeColor = Color.FromArgb(0, 96, 148);
            lblDirection.Location = new Point(6, 31);
            lblDirection.Name = "lblDirection";
            lblDirection.Size = new Size(212, 14);
            lblDirection.TabIndex = 2;
            lblDirection.Text = "Dir   : IDLE";
            lblDirection.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblInnerDoor
            // 
            lblInnerDoor.BackColor = Color.Transparent;
            lblInnerDoor.Font = new Font("Consolas", 8.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblInnerDoor.ForeColor = Color.FromArgb(0, 96, 148);
            lblInnerDoor.Location = new Point(6, 45);
            lblInnerDoor.Name = "lblInnerDoor";
            lblInnerDoor.Size = new Size(212, 14);
            lblInnerDoor.TabIndex = 3;
            lblInnerDoor.Text = "Inner : CLOSED";
            lblInnerDoor.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblOuterDoor
            // 
            lblOuterDoor.BackColor = Color.Transparent;
            lblOuterDoor.Font = new Font("Consolas", 8.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblOuterDoor.ForeColor = Color.FromArgb(0, 96, 148);
            lblOuterDoor.Location = new Point(6, 59);
            lblOuterDoor.Name = "lblOuterDoor";
            lblOuterDoor.Size = new Size(212, 14);
            lblOuterDoor.TabIndex = 4;
            lblOuterDoor.Text = "Outer : CLOSED [G]";
            lblOuterDoor.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblDoor
            // 
            lblDoor.BackColor = Color.Transparent;
            lblDoor.Font = new Font("Consolas", 8.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDoor.ForeColor = Color.FromArgb(0, 96, 148);
            lblDoor.Location = new Point(6, 73);
            lblDoor.Name = "lblDoor";
            lblDoor.Size = new Size(212, 14);
            lblDoor.TabIndex = 5;
            lblDoor.Text = "Doors : CLOSED";
            lblDoor.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblStatus
            // 
            lblStatus.BackColor = Color.Transparent;
            lblStatus.Font = new Font("Consolas", 8.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblStatus.ForeColor = Color.FromArgb(0, 96, 148);
            lblStatus.Location = new Point(6, 87);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(212, 14);
            lblStatus.TabIndex = 6;
            lblStatus.Text = "State : READY";
            lblStatus.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblQueue
            // 
            lblQueue.BackColor = Color.Transparent;
            lblQueue.Font = new Font("Consolas", 8.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblQueue.ForeColor = Color.FromArgb(0, 96, 148);
            lblQueue.Location = new Point(6, 101);
            lblQueue.Name = "lblQueue";
            lblQueue.Size = new Size(212, 14);
            lblQueue.TabIndex = 7;
            lblQueue.Text = "Queue : -";
            lblQueue.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // pnlInfo
            // 
            pnlInfo.Controls.Add(lblCurrentFloor);
            pnlInfo.Controls.Add(lblDestination);
            pnlInfo.Controls.Add(lblDirection);
            pnlInfo.Controls.Add(lblInnerDoor);
            pnlInfo.Controls.Add(lblOuterDoor);
            pnlInfo.Controls.Add(lblDoor);
            pnlInfo.Controls.Add(lblStatus);
            pnlInfo.Controls.Add(lblQueue);
            pnlInfo.BackColor = Color.FromArgb(255, 255, 255);
            pnlInfo.Location = new Point(116, 54);
            pnlInfo.Name = "pnlInfo";
            pnlInfo.Size = new Size(222, 118);
            pnlInfo.TabIndex = 2;
            // 
            // lblMessage
            // 
            lblMessage.BackColor = Color.FromArgb(255, 255, 255);
            lblMessage.Font = new Font("Consolas", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMessage.ForeColor = Color.FromArgb(0, 96, 148);
            lblMessage.Location = new Point(12, 180);
            lblMessage.Name = "lblMessage";
            lblMessage.Size = new Size(326, 36);
            lblMessage.TabIndex = 3;
            lblMessage.Text = "Floor: G   IDLE";
            lblMessage.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblEmergencyLamp
            // 
            lblEmergencyLamp.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblEmergencyLamp.Location = new Point(12, 222);
            lblEmergencyLamp.Name = "lblEmergencyLamp";
            lblEmergencyLamp.Size = new Size(104, 24);
            lblEmergencyLamp.TabIndex = 4;
            lblEmergencyLamp.Text = "\u25CF EMERGENCY";
            lblEmergencyLamp.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblAlarmLamp
            // 
            lblAlarmLamp.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAlarmLamp.Location = new Point(123, 222);
            lblAlarmLamp.Name = "lblAlarmLamp";
            lblAlarmLamp.Size = new Size(104, 24);
            lblAlarmLamp.TabIndex = 5;
            lblAlarmLamp.Text = "\u25CF ALARM";
            lblAlarmLamp.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblInterlockLamp
            // 
            lblInterlockLamp.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblInterlockLamp.Location = new Point(234, 222);
            lblInterlockLamp.Name = "lblInterlockLamp";
            lblInterlockLamp.Size = new Size(104, 24);
            lblInterlockLamp.TabIndex = 6;
            lblInterlockLamp.Text = "\u25CF INTERLOCK";
            lblInterlockLamp.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblFloorCaption
            // 
            lblFloorCaption.BackColor = Color.Transparent;
            lblFloorCaption.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblFloorCaption.Location = new Point(12, 254);
            lblFloorCaption.Name = "lblFloorCaption";
            lblFloorCaption.Size = new Size(74, 16);
            lblFloorCaption.TabIndex = 7;
            lblFloorCaption.Text = "FLOOR";
            lblFloorCaption.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblMovementCaption
            // 
            lblMovementCaption.BackColor = Color.Transparent;
            lblMovementCaption.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMovementCaption.Location = new Point(94, 254);
            lblMovementCaption.Name = "lblMovementCaption";
            lblMovementCaption.Size = new Size(112, 16);
            lblMovementCaption.TabIndex = 8;
            lblMovementCaption.Text = "MOVE";
            lblMovementCaption.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblDoorCaption
            // 
            lblDoorCaption.BackColor = Color.Transparent;
            lblDoorCaption.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDoorCaption.Location = new Point(214, 254);
            lblDoorCaption.Name = "lblDoorCaption";
            lblDoorCaption.Size = new Size(124, 16);
            lblDoorCaption.TabIndex = 9;
            lblDoorCaption.Text = "DOOR";
            lblDoorCaption.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // btnFloor1
            // 
            btnFloor1.Font = new Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnFloor1.Location = new Point(12, 274);
            btnFloor1.Name = "btnFloor1";
            btnFloor1.Size = new Size(74, 52);
            btnFloor1.TabIndex = 10;
            btnFloor1.Text = "1";
            // 
            // btnUp
            // 
            btnUp.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnUp.Location = new Point(94, 274);
            btnUp.Name = "btnUp";
            btnUp.Size = new Size(112, 52);
            btnUp.TabIndex = 11;
            btnUp.Text = "\u2191 UP";
            // 
            // btnOpenDoor
            // 
            btnOpenDoor.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnOpenDoor.Location = new Point(214, 274);
            btnOpenDoor.Name = "btnOpenDoor";
            btnOpenDoor.Size = new Size(124, 52);
            btnOpenDoor.TabIndex = 12;
            btnOpenDoor.Text = "OPEN DOOR";
            // 
            // btnFloorG
            // 
            btnFloorG.Font = new Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnFloorG.Location = new Point(12, 332);
            btnFloorG.Name = "btnFloorG";
            btnFloorG.Size = new Size(74, 52);
            btnFloorG.TabIndex = 13;
            btnFloorG.Text = "G";
            // 
            // btnDown
            // 
            btnDown.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDown.Location = new Point(94, 332);
            btnDown.Name = "btnDown";
            btnDown.Size = new Size(112, 52);
            btnDown.TabIndex = 14;
            btnDown.Text = "\u2193 DOWN";
            // 
            // btnCloseDoor
            // 
            btnCloseDoor.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCloseDoor.Location = new Point(214, 332);
            btnCloseDoor.Name = "btnCloseDoor";
            btnCloseDoor.Size = new Size(124, 52);
            btnCloseDoor.TabIndex = 15;
            btnCloseDoor.Text = "CLOSE DOOR";
            // 
            // lblSafetyCaption
            // 
            lblSafetyCaption.BackColor = Color.Transparent;
            lblSafetyCaption.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblSafetyCaption.Location = new Point(12, 392);
            lblSafetyCaption.Name = "lblSafetyCaption";
            lblSafetyCaption.Size = new Size(326, 16);
            lblSafetyCaption.TabIndex = 16;
            lblSafetyCaption.Text = "SAFETY";
            lblSafetyCaption.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // btnEmergency
            // 
            btnEmergency.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEmergency.Location = new Point(12, 412);
            btnEmergency.Name = "btnEmergency";
            btnEmergency.Size = new Size(170, 52);
            btnEmergency.TabIndex = 17;
            btnEmergency.Text = "EMERGENCY STOP";
            // 
            // btnAlarm
            // 
            btnAlarm.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAlarm.Location = new Point(188, 412);
            btnAlarm.Name = "btnAlarm";
            btnAlarm.Size = new Size(80, 52);
            btnAlarm.TabIndex = 18;
            btnAlarm.Text = "ALARM";
            // 
            // btnReset
            // 
            btnReset.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReset.Location = new Point(274, 412);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(64, 52);
            btnReset.TabIndex = 19;
            btnReset.Text = "RESET";
            // 
            // btnLoadMinus
            // 
            btnLoadMinus.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLoadMinus.Location = new Point(12, 474);
            btnLoadMinus.Name = "btnLoadMinus";
            btnLoadMinus.Size = new Size(80, 36);
            btnLoadMinus.TabIndex = 20;
            btnLoadMinus.Text = "\u2212 100";
            // 
            // lblLoad
            // 
            lblLoad.BackColor = Color.FromArgb(255, 255, 255);
            lblLoad.Font = new Font("Consolas", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblLoad.ForeColor = Color.FromArgb(0, 96, 148);
            lblLoad.Location = new Point(98, 474);
            lblLoad.Name = "lblLoad";
            lblLoad.Size = new Size(142, 36);
            lblLoad.TabIndex = 21;
            lblLoad.Text = "LOAD 0 / 800 kg";
            lblLoad.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnLoadPlus
            // 
            btnLoadPlus.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLoadPlus.Location = new Point(246, 474);
            btnLoadPlus.Name = "btnLoadPlus";
            btnLoadPlus.Size = new Size(92, 36);
            btnLoadPlus.TabIndex = 22;
            btnLoadPlus.Text = "+ 100";
            // 
            // pnlPanel
            // 
            pnlPanel.Controls.Add(lblTitle);
            pnlPanel.Controls.Add(ledFloor);
            pnlPanel.Controls.Add(pnlInfo);
            pnlPanel.Controls.Add(lblMessage);
            pnlPanel.Controls.Add(lblEmergencyLamp);
            pnlPanel.Controls.Add(lblAlarmLamp);
            pnlPanel.Controls.Add(lblInterlockLamp);
            pnlPanel.Controls.Add(lblFloorCaption);
            pnlPanel.Controls.Add(lblMovementCaption);
            pnlPanel.Controls.Add(lblDoorCaption);
            pnlPanel.Controls.Add(btnFloor1);
            pnlPanel.Controls.Add(btnUp);
            pnlPanel.Controls.Add(btnOpenDoor);
            pnlPanel.Controls.Add(btnFloorG);
            pnlPanel.Controls.Add(btnDown);
            pnlPanel.Controls.Add(btnCloseDoor);
            pnlPanel.Controls.Add(lblSafetyCaption);
            pnlPanel.Controls.Add(btnEmergency);
            pnlPanel.Controls.Add(btnAlarm);
            pnlPanel.Controls.Add(btnReset);
            pnlPanel.Controls.Add(btnLoadMinus);
            pnlPanel.Controls.Add(lblLoad);
            pnlPanel.Controls.Add(btnLoadPlus);
            pnlPanel.Location = new Point(0, 0);
            pnlPanel.Name = "pnlPanel";
            pnlPanel.Size = new Size(350, 520);
            pnlPanel.TabIndex = 1;
            // 
            // LiftUnit
            // 
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            BackColor = Color.FromArgb(255, 255, 255);
            Controls.Add(shaft);
            Controls.Add(pnlPanel);
            Name = "LiftUnit";
            Size = new Size(700, 520);
            btnFloorG.Click += btnFloor_Click;
            btnFloor1.Click += btnFloor_Click;
            btnUp.Click += btnUp_Click;
            btnDown.Click += btnDown_Click;
            btnOpenDoor.Click += btnOpenDoor_Click;
            btnCloseDoor.Click += btnCloseDoor_Click;
            btnEmergency.Click += btnEmergency_Click;
            btnAlarm.Click += btnAlarm_Click;
            btnReset.Click += btnReset_Click;
            btnLoadMinus.Click += btnLoadMinus_Click;
            btnLoadPlus.Click += btnLoadPlus_Click;
            pnlPanel.ResumeLayout(false);
            pnlInfo.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private ElevatorShaft shaft;
        private CardPanel pnlPanel;
        private Label lblTitle;
        private LedDisplay ledFloor;
        private DisplayPanel pnlInfo;
        private Label lblCurrentFloor;
        private Label lblDestination;
        private Label lblDirection;
        private Label lblInnerDoor;
        private Label lblOuterDoor;
        private Label lblDoor;
        private Label lblStatus;
        private Label lblQueue;
        private DisplayLabel lblMessage;
        private DisplayLabel lblEmergencyLamp;
        private DisplayLabel lblAlarmLamp;
        private DisplayLabel lblInterlockLamp;
        private SectionLabel lblFloorCaption;
        private SectionLabel lblMovementCaption;
        private SectionLabel lblDoorCaption;
        private SteelButton btnFloor1;
        private SteelButton btnUp;
        private SteelButton btnOpenDoor;
        private SteelButton btnFloorG;
        private SteelButton btnDown;
        private SteelButton btnCloseDoor;
        private SectionLabel lblSafetyCaption;
        private SteelButton btnEmergency;
        private SteelButton btnAlarm;
        private SteelButton btnReset;
        private SteelButton btnLoadMinus;
        private DisplayLabel lblLoad;
        private SteelButton btnLoadPlus;
    }
}
