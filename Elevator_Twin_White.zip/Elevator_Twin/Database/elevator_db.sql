-- =====================================================================
--  Twin Lift Control Room  -  MySQL schema + useful queries (Lift A and Lift B)
--  Run in MySQL Workbench (connection "lift"): File > Open SQL Script,
--  then press the lightning bolt.  The program also creates these
--  objects by itself on first start, so running this is optional.
-- =====================================================================

-- 1. Database ----------------------------------------------------------
CREATE DATABASE IF NOT EXISTS Hansel
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE Hansel;

-- 2. Log table ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS elevator_log (
    log_id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    elevator_name VARCHAR(20)  NOT NULL,                 -- 'Lift A' or 'Lift B' (two lifts write into the same table)
    floor_no      TINYINT      NOT NULL,                 -- 1 = G (Ground), 2 = 1 (First floor)
    status        VARCHAR(120) NOT NULL,                 -- e.g. 'Going UP: Ground Floor to First Floor'
    log_time      DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (log_id),
    INDEX idx_log_time (log_time),
    INDEX idx_log_elevator (elevator_name)
) ENGINE = InnoDB;

-- 3. View that looks exactly like the grid in the application -------------
CREATE OR REPLACE VIEW vw_elevator_log AS
SELECT  log_id                              AS ID,
        DATE_FORMAT(log_time, '%d/%m/%Y')   AS `Date`,
        DATE_FORMAT(log_time, '%H:%i:%s')   AS `Time`,
        elevator_name                       AS Elevator,
        CASE floor_no WHEN 1 THEN 'G' ELSE CAST(floor_no - 1 AS CHAR) END AS Floor,
        status                              AS `Action`
FROM    elevator_log
ORDER BY log_id DESC;

-- =====================================================================
--  Useful queries
-- =====================================================================

-- Newest 50 records (what the "Show Log" button displays)
SELECT * FROM vw_elevator_log LIMIT 50;

-- Number of events per elevator
SELECT elevator_name, COUNT(*) AS events
FROM   elevator_log
GROUP  BY elevator_name;

-- Number of trips (arrivals)
SELECT elevator_name, COUNT(*) AS trips
FROM   elevator_log
WHERE  status LIKE 'ARRIVED AT%'
GROUP  BY elevator_name;

-- Which floor is visited most often
SELECT floor_no, COUNT(*) AS arrivals
FROM   elevator_log
WHERE  status LIKE 'ARRIVED AT%'
GROUP  BY floor_no
ORDER  BY arrivals DESC;

-- Events of one day
SELECT * FROM elevator_log
WHERE  DATE(log_time) = CURDATE()
ORDER  BY log_time;

-- Events of the last 10 minutes
SELECT * FROM elevator_log
WHERE  log_time >= NOW() - INTERVAL 10 MINUTE
ORDER  BY log_time DESC;

-- Emergency stops, resets and alarms
SELECT log_time, floor_no, status
FROM   elevator_log
WHERE  status LIKE 'EMERGENCY%' OR status LIKE 'RESET%' OR status LIKE 'ALARM%' OR status LIKE 'INTERLOCK%'
ORDER  BY log_id DESC;

-- Delete the whole log (the "Clear Log" button does this)
-- TRUNCATE TABLE elevator_log;

-- Delete only records older than 30 days
-- DELETE FROM elevator_log WHERE log_time < NOW() - INTERVAL 30 DAY;


-- 6. Twin lifts: queries per lift ------------------------------------------
-- Newest events of one lift
-- SELECT * FROM vw_elevator_log WHERE Elevator = 'Lift A' LIMIT 50;
-- How many events did each lift write?
-- SELECT elevator_name, COUNT(*) AS events FROM elevator_log GROUP BY elevator_name;
-- Emergency stops, alarms and overloads of both lifts
-- SELECT log_time, elevator_name, status FROM elevator_log
--  WHERE status LIKE 'EMERGENCY%' OR status LIKE 'ALARM%' OR status LIKE 'OVERLOAD%' ORDER BY log_id DESC;
