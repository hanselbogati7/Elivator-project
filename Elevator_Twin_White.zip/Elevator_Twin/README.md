# Twin Lift Control Room (C# WinForms, .NET 10, MySQL) - Emerald

**TWO independent lifts - Lift A and Lift B - in one window.** Each lift is a complete copy of the single-lift
simulator below (own model, own timer, own state machine, own shaft picture, own control panel, own alarm and load).
Lift A starts on G, Lift B on floor 1. They never influence each other: you can send one up while the other goes down,
stop one in an emergency or overload the other. Every event is written to the same MySQL log with the lift name
(`Lift A` / `Lift B`).

New layout: header bar (title, clock, log filter, Show Log / Clear Log / Exit) on top; **Lift A panel | Lift A shaft | Lift B shaft | Lift B panel**
in the middle; the full-width event log along the bottom (filter: All lifts / Lift A / Lift B).

Each lift behaves like this (unchanged from your FIXED version): ONE elevator serving the floors (**G, 1**) with a **true dual-door system**:

| Door | Belongs to | Moves with the cabin? |
|------|-----------|-----------------------|
| **Inner (cabin) door** - bright silver, amber trim | the cabin | **Yes** - travels up and down with it |
| **Outer (landing) doors** - graphite, one set per floor, with steel frame, bolts, hall indicator and state lamp | the building / the floor | **Never** - they stay at their floor for ever |

The shaft is drawn as a cut-away: the cabin (wider than a door, with a `CAR` badge) travels through the hoistway
*behind* the fixed landing-door frames. A dashed `LEVEL` line and a steel floor-edge strip at every floor show the alignment.
Everything in the picture is drawn from the model (`Elevator.Position`, `Inner.Openness`, `GetLanding(floor).Openness`).

Adding floors: change `Elevator.MaxFloor` (one number) - the shaft and the logic adapt (the panel has one floor button per floor: add one to `LiftUnit`).

## Run it
1. Start your MySQL server (127.0.0.1:3306, user root - see `dbsettings.json`).
2. Open `Elevator_Twin.sln` in Visual Studio and press F5 (first build needs internet for the NuGet package `MySqlConnector`).
3. The program creates database `Hansel` and table `elevator_log` by itself (or run `Database\elevator_db.sql`).

## Door states and synchronisation
States: `CLOSED`, `OPENING`, `OPEN`, `CLOSING`, `LOCKED`.

* Arrival: cabin levels exactly on the floor -> `ARRIVED AT FLOOR n` -> inner door + **that floor's** outer door unlock
  -> `INNER DOOR OPENING`, `FLOOR n OUTER DOOR OPENING` -> both open together (same openness every tick) -> `DOORS OPEN`.
* The doors stay open for 4 s (1.5 s once another floor has been requested), then `DOORS CLOSING` -> `DOORS CLOSED` -> `READY`.
  `OPEN DOOR` / `CLOSE DOOR` work at any time while the cabin stands at a floor.
* Before leaving: `ALL DOORS LOCKED` - inner door and all landing doors are `LOCKED` while the cabin travels.

## Safety interlock
* The cabin only starts when the inner door **and every** landing door are completely closed.
* The interlock is re-checked on every movement tick (a violation triggers an emergency stop - `INTERLOCK FAULT`).
* A landing door only unlocks/opens for the floor the cabin is levelled at and stopped on; all other floors stay `LOCKED`.
* **EMERGENCY STOP** stops the timer at once (cabin and doors freeze), drops all requests and blocks everything until **RESET**.
* **ALARM**: flashing lamp/message, repeating tone, log entry, stops by itself after 6 s or with RESET.
* Invalid controls are disabled automatically: no DOWN at G, no UP at the top floor, no floor/UP/DOWN while a door is open,
  opening or closing, nothing but ALARM/RESET during an emergency stop.

## Requests and movement
Floor buttons (and the call buttons on the wall) put floors into a request queue (`Requests:` line, lit buttons).
The cabin keeps its direction while there are requests ahead, may add a stop on the way, speeds up / slows down
and levels exactly on the floor. `UP`/`DOWN` request the next floor above/below.

## Control panel (one card per lift)
Top: lift name, big FLOOR display and a status list (Floor, Dest, Dir, Inner, Outer, Doors, State, Queue), the message line and the lamps
EMERGENCY / ALARM / INTERLOCK (green = movement allowed, amber = a door is not closed, red = emergency).
Middle: the FLOOR buttons as a vertical car panel (`1` above `G`), MOVE (UP / DOWN) and DOOR (OPEN / CLOSE) next to them.
Bottom: SAFETY (EMERGENCY STOP, ALARM, RESET) and the cabin LOAD (`-100` / `+100`, overload above 800 kg blocks the lift).

## Event log (MySQL, ID / Date / Time / Elevator = Lift A or Lift B / Floor / Action)
`SYSTEM STARTED`, `REQUESTED FLOOR 2`, `ALL DOORS LOCKED`, `GOING UP: GROUND FLOOR TO FLOOR 2`, `PASSING FLOOR 1 - LANDING DOOR STAYS LOCKED`,
`STOP ADDED AT ...`, `ARRIVED AT FLOOR 2`, `DOORS UNLOCKED`, `INNER DOOR OPENING`, `FLOOR 2 OUTER DOOR OPENING`, `DOORS OPEN`,
`DOORS CLOSING`, `DOORS CLOSED`, `READY`, `EMERGENCY STOP ACTIVATED`, `ALARM ACTIVATED`, `RESET - ...`, `INTERLOCK FAULT ...`.

## Files
- `Elevator.cs` - model: `Door` / `DoorState`, request queue, door synchronisation, interlock, emergency, alarm
- `ElevatorStates.cs` - State pattern: Idle (dispatcher) / Moving (speed profile, levelling, interlock check) / Emergency
- `ElevatorController.cs` - controller + `LogObserver` (every event is written to MySQL)
- `Controls.cs` - `ElevatorShaft` (cabin + landing doors), `DoorArt`, `SteelButton`, `SteelPanel`, `CardPanel`, `LedDisplay`, `DisplayLabel`/`DisplayPanel`, `SectionLabel`
- `Theme.cs` - the single Emerald Control Room theme
- `LiftUnit.cs` / `LiftUnit.Designer.cs` - ONE complete lift (shaft + control card + its own `Elevator`); the window contains two
- `Form1.cs` / `Form1.Designer.cs` - header, the two `LiftUnit`s, shared log grid with lift filter
- `LogRepository.cs` - MySQL access (reads the extra `Floor` column from `floor_no`; table unchanged)

## Table `elevator_log` (unchanged)
| Column        | Type            | Meaning                          |
|---------------|-----------------|----------------------------------|
| log_id        | INT AUTO_INCREMENT PK | record number              |
| elevator_name | VARCHAR(20)     | "Elevator"                       |
| floor_no      | TINYINT         | 1 = G, 2 = 1, 3 = 2              |
| status        | VARCHAR(120)    | what happened                    |
| log_time      | DATETIME(3)     | date and time of the event       |
