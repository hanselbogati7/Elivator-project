namespace Elevator_Twin
{
    /// <summary>Owns the single elevator and translates the control-panel commands into requests.</summary>
    public class ElevatorController
    {
        public Elevator Elevator { get; }

        public ElevatorController(Elevator elevator) => Elevator = elevator;

        /// <summary>UP: request the next floor above the cabin (nothing happens at the top floor).</summary>
        public void GoUp()
        {
            int floor = Elevator.NextFloorAbove;
            if (floor <= Elevator_Twin.Elevator.MaxFloor) Elevator.RequestFloor(floor);
        }

        /// <summary>DOWN: request the next floor below the cabin (nothing happens at the ground floor).</summary>
        public void GoDown()
        {
            int floor = Elevator.NextFloorBelow;
            if (floor >= Elevator_Twin.Elevator.MinFloor) Elevator.RequestFloor(floor);
        }
    }

    /// <summary>Observer that turns every elevator event into a database log entry.</summary>
    public class LogObserver : IElevatorObserver
    {
        private readonly LogRepository _repository;

        public LogObserver(LogRepository repository) => _repository = repository;

        public void OnElevatorEvent(Elevator elevator, string status)
        {
            _repository.Enqueue(new LogEntry(elevator.Name, elevator.CurrentFloor, status, DateTime.Now));
        }
    }
}
