using System.Data;
using System.Drawing.Drawing2D;

namespace Elevator_Twin
{
    /// <summary>
    /// The control room: a header bar, two completely independent lifts (Lift A on the left with its panel on the
    /// left, Lift B on the right with its panel on the right) and one shared event log along the bottom.
    /// </summary>
    public partial class Form1 : Form
    {
        private LogRepository _repository;
        private bool _dbErrorShown;
        private bool _loadingLog;

        private readonly System.Windows.Forms.Timer _clockTimer = new() { Interval = 250 };

        private const int HeaderHeight = 56;

        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true;
            liftB.Mirrored = true;                  // Lift B: shaft on the left, its control panel on the right
            cboLogFilter.SelectedIndex = 0;         // all lifts
            ApplyTheme();
        }

        /// <summary>White window with a header bar and a soft accent line under it.</summary>
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            if (ClientRectangle.Width < 2 || ClientRectangle.Height < 2) return;
            ThemeData t = Theme.Current;

            using (var back = new SolidBrush(t.FormBack))
                g.FillRectangle(back, ClientRectangle);

            var header = new Rectangle(0, 0, ClientSize.Width, HeaderHeight);
            using (var hb = new LinearGradientBrush(header, t.HeaderTop, t.HeaderBottom, 90f))
                g.FillRectangle(hb, header);
            using (var line = new SolidBrush(t.Accent))
                g.FillRectangle(line, 0, HeaderHeight - 3, ClientSize.Width, 3);

            // dividing line between the lifts and the log
            using (var pen = new Pen(Color.FromArgb(70, t.Accent), 1))
                g.DrawLine(pen, 20, dgvLog.Top - 7, ClientSize.Width - 20, dgvLog.Top - 7);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            _repository = new LogRepository();
            _repository.ErrorOccurred += OnDatabaseError;
            _repository.EntriesWritten += () => LoadLog(false);   // keep the grid up to date
            lblDbStatus.Text = "Database: " + LogRepository.Description;

            liftA.Start("Lift A", Elevator.MinFloor, _repository);   // Lift A starts on G
            liftB.Start("Lift B", Elevator.MaxFloor, _repository);   // Lift B starts on floor 1

            _clockTimer.Tick += (s, a) => UpdateClock();
            _clockTimer.Start();
            UpdateClock();
            LoadLog(false);
        }

        private void UpdateClock() => lblClock.Text = DateTime.Now.ToString("dd MMM yyyy  HH:mm:ss");

        // ---------------------------------------------------------- theme

        private void ApplyTheme()
        {
            ThemeData t = Theme.Current;
            BackColor = t.FormBack;

            lblTitle.ForeColor = t.Accent;
            lblFilter.ForeColor = t.TextLight;
            lblDbStatus.ForeColor = t.TextLight;
            lblClock.BackColor = t.DisplayBack;
            lblClock.ForeColor = t.Led;
            cboLogFilter.BackColor = t.DisplayBack;
            cboLogFilter.ForeColor = t.Led;

            dgvLog.EnableHeadersVisualStyles = false;
            dgvLog.BackgroundColor = t.GridBack;
            dgvLog.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvLog.GridColor = t.PanelEdge;
            dgvLog.RowTemplate.Height = 26;
            dgvLog.ColumnHeadersHeight = 30;
            dgvLog.DefaultCellStyle.Font = new Font("Segoe UI", 9.5F);
            dgvLog.DefaultCellStyle.Padding = new Padding(4, 0, 4, 0);
            dgvLog.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(246, 248, 251);
            dgvLog.AlternatingRowsDefaultCellStyle.ForeColor = t.TextLight;
            dgvLog.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI Semibold", 9.5F, FontStyle.Bold);
            dgvLog.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dgvLog.DefaultCellStyle.BackColor = t.GridBack;
            dgvLog.DefaultCellStyle.ForeColor = t.TextLight;
            dgvLog.DefaultCellStyle.SelectionBackColor = t.Accent;
            dgvLog.DefaultCellStyle.SelectionForeColor = Color.Black;
            dgvLog.ColumnHeadersDefaultCellStyle.BackColor = t.Metal[0];
            dgvLog.ColumnHeadersDefaultCellStyle.ForeColor = t.Ink;
            dgvLog.ColumnHeadersDefaultCellStyle.SelectionBackColor = t.Metal[0];
        }

        // ---------------------------------------------------------- log (MySQL)

        private void OnDatabaseError(string message)
        {
            lblDbStatus.Text = "Database error: " + message;
            if (_dbErrorShown) return;      // show the full text once, so it can be read and copied
            _dbErrorShown = true;
            MessageBox.Show(message, "Database error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void btnLog_Click(object sender, EventArgs e) => LoadLog(true);

        private void LoadLog(bool userInitiated)
        {
            if (_loadingLog) return;
            _loadingLog = true;
            _repository.LoadLogsAsync(
                table =>
                {
                    _loadingLog = false;
                    dgvLog.DataSource = table;
                    FormatLogGrid();
                    ApplyLogFilter();
                    lblDbStatus.Text = $"Log: {table.Rows.Count} newest records loaded.";
                },
                error =>
                {
                    _loadingLog = false;
                    lblDbStatus.Text = "Database error: " + error;
                    if (userInitiated)
                        MessageBox.Show(error, "Database error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                });
        }

        /// <summary>Shows the events of all lifts, or only those of Lift A or Lift B (the filter works on the loaded table).</summary>
        private void ApplyLogFilter()
        {
            if (dgvLog.DataSource is not DataTable table) return;
            string selected = cboLogFilter.SelectedItem as string;
            table.DefaultView.RowFilter = (selected == null || selected == "All lifts")
                ? string.Empty
                : $"Elevator = '{selected.Replace("'", "''")}'";
        }

        private void cboLogFilter_SelectedIndexChanged(object sender, EventArgs e) => ApplyLogFilter();

        private void FormatLogGrid()
        {
            if (dgvLog.Columns.Count < 6) return;
            dgvLog.Columns["ID"].FillWeight = 24;
            dgvLog.Columns["Date"].FillWeight = 50;
            dgvLog.Columns["Time"].FillWeight = 42;
            dgvLog.Columns["Elevator"].FillWeight = 42;
            dgvLog.Columns["Floor"].FillWeight = 26;
            dgvLog.Columns["Action"].FillWeight = 130;
        }

        private void btnClearLog_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Delete the whole elevator log (both lifts)?", "Clear Log",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            _repository.ClearAsync(
                () => LoadLog(true),
                error => MessageBox.Show(error, "Database error", MessageBoxButtons.OK, MessageBoxIcon.Warning));
        }

        private void btnExit_Click(object sender, EventArgs e) => Close();

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            _clockTimer.Stop();
            _clockTimer.Dispose();
            liftA.Shutdown();
            liftB.Shutdown();
            _repository?.Flush();
        }
    }
}
