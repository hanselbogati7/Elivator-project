using System.Collections.Concurrent;
using System.ComponentModel;
using System.Data;
using System.Text.Json;
using MySqlConnector;

namespace Elevator_Twin
{
    public record LogEntry(string ElevatorName, int Floor, string Status, DateTime Time);

    /// <summary>Connection settings, read from dbsettings.json (relative to the program, not hard-coded).</summary>
    public class DbSettings
    {
        public string Host { get; set; } = "127.0.0.1";
        public int Port { get; set; } = 3306;
        public string User { get; set; } = "root";
        public string Password { get; set; } = "";
        public string Database { get; set; } = "elevator_db";

        [System.Text.Json.Serialization.JsonIgnore]
        public string LoadError { get; private set; }

        public static DbSettings Load()
        {
            try
            {
                // look next to the exe first, then in the parent folders (works from Visual Studio's bin\Debug)
                string dir = AppContext.BaseDirectory;
                for (int i = 0; i < 7 && dir != null; i++)
                {
                    string file = Path.Combine(dir, "dbsettings.json");
                    if (File.Exists(file))
                    {
                        var s = JsonSerializer.Deserialize<DbSettings>(File.ReadAllText(file),
                            new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                        return s ?? new DbSettings();
                    }
                    dir = Path.GetDirectoryName(dir.TrimEnd(Path.DirectorySeparatorChar));
                }
                return new DbSettings { LoadError = "dbsettings.json was not found next to the program." };
            }
            catch (Exception ex)
            {
                return new DbSettings { LoadError = "dbsettings.json could not be read: " + ex.Message };
            }
        }
    }

    /// <summary>
    /// All database access (MySQL) lives here. Every operation runs on a BackgroundWorker
    /// so the GUI never freezes.
    /// </summary>
    public class LogRepository
    {
        private const string TableName = "elevator_log";
        private static readonly DbSettings Settings = DbSettings.Load();

        private readonly ConcurrentQueue<LogEntry> _queue = new();
        private readonly BackgroundWorker _writer = new();
        private readonly object _schemaLock = new();
        private bool _schemaChecked;
        private volatile bool _wroteSomething;

        /// <summary>Raised on the GUI thread when a database operation fails.</summary>
        public event Action<string> ErrorOccurred;

        /// <summary>Raised on the GUI thread after new log entries were stored.</summary>
        public event Action EntriesWritten;

        public static string Description =>
            $"MySQL  {Settings.User}@{Settings.Host}:{Settings.Port}  /  {Settings.Database}";

        public LogRepository()
        {
            _writer.DoWork += Writer_DoWork;
            _writer.RunWorkerCompleted += Writer_Completed;
        }

        // ------------------------------------------------------------ writing (queued)

        public void Enqueue(LogEntry entry)
        {
            _queue.Enqueue(entry);
            StartWriterIfNeeded();
        }

        private void StartWriterIfNeeded()
        {
            if (!_writer.IsBusy && !_queue.IsEmpty)
                _writer.RunWorkerAsync();
        }

        private void Writer_DoWork(object sender, DoWorkEventArgs e)
        {
            while (_queue.TryDequeue(out LogEntry entry))
            {
                try
                {
                    Insert(entry);
                    _wroteSomething = true;
                }
                catch (Exception ex)
                {
                    e.Result = ex.Message;
                    while (_queue.TryDequeue(out _)) { }   // database unusable: do not retry every entry
                }
            }
        }

        private void Writer_Completed(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null) ErrorOccurred?.Invoke(e.Error.Message);
            else if (e.Result is string message) ErrorOccurred?.Invoke(message);

            if (_wroteSomething)
            {
                _wroteSomething = false;
                EntriesWritten?.Invoke();
            }
            StartWriterIfNeeded();
        }

        /// <summary>Writes anything still queued (called when the form closes).</summary>
        public void Flush()
        {
            while (_queue.TryDequeue(out LogEntry entry))
            {
                try { Insert(entry); } catch { break; }
            }
        }

        // ------------------------------------------------------------ reading / clearing (async)

        public void LoadLogsAsync(Action<DataTable> onLoaded, Action<string> onError) =>
            RunAsync(ReadAll, onLoaded, onError);

        public void ClearAsync(Action onDone, Action<string> onError) =>
            RunAsync(() => Execute($"TRUNCATE TABLE {TableName}"), _ => onDone(), onError);

        /// <summary>One place that runs work on a BackgroundWorker and reports back on the GUI thread.</summary>
        private static void RunAsync<T>(Func<T> work, Action<T> onDone, Action<string> onError)
        {
            var worker = new BackgroundWorker();
            worker.DoWork += (s, e) => e.Result = work();
            worker.RunWorkerCompleted += (s, e) =>
            {
                if (e.Error != null) onError(e.Error.Message);
                else onDone((T)e.Result);
                worker.Dispose();
            };
            worker.RunWorkerAsync();
        }

        // ------------------------------------------------------------ SQL

        private void Insert(LogEntry entry)
        {
            Execute(
                $"INSERT INTO {TableName} (elevator_name, floor_no, status, log_time) VALUES (@name, @floor, @status, @time)",
                new MySqlParameter("@name", entry.ElevatorName),
                new MySqlParameter("@floor", entry.Floor),
                new MySqlParameter("@status", entry.Status),
                new MySqlParameter("@time", entry.Time));
        }

        /// <summary>Reads the newest records and shapes them like the log grid: ID, Date, Time, Elevator, Floor, Action.</summary>
        private DataTable ReadAll()
        {
            return WithConnection(conn =>
            {
                var table = new DataTable();
                table.Columns.Add("ID", typeof(int));
                table.Columns.Add("Date", typeof(string));
                table.Columns.Add("Time", typeof(string));
                table.Columns.Add("Elevator", typeof(string));
                table.Columns.Add("Floor", typeof(string));
                table.Columns.Add("Action", typeof(string));

                using var cmd = new MySqlCommand(
                    $"SELECT log_id, elevator_name, log_time, status, floor_no FROM {TableName} ORDER BY log_id DESC LIMIT 500", conn);
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    DateTime t = reader.GetDateTime(2);
                    table.Rows.Add(reader.GetInt32(0), t.ToString("dd/MM/yyyy"), t.ToString("HH:mm:ss"),
                                   reader.GetString(1), Elevator.FloorName(Convert.ToInt32(reader.GetValue(4))), reader.GetString(3));
                }
                return table;
            });
        }

        private int Execute(string sql, params MySqlParameter[] parameters)
        {
            return WithConnection(conn =>
            {
                using var cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddRange(parameters);
                return cmd.ExecuteNonQuery();
            });
        }

        // ------------------------------------------------------------ connection handling

        private T WithConnection<T>(Func<MySqlConnection, T> work)
        {
            using MySqlConnection conn = OpenConnection();
            return work(conn);
        }

        private MySqlConnection OpenConnection()
        {
            if (Settings.LoadError != null)
                throw new InvalidOperationException(Settings.LoadError);

            var builder = new MySqlConnectionStringBuilder
            {
                Server = Settings.Host,
                Port = (uint)Settings.Port,
                UserID = Settings.User,
                Password = Settings.Password,      // the builder handles special characters such as @ and $
                ConnectionTimeout = 5,
                AllowPublicKeyRetrieval = true,    // needed for MySQL 8 on localhost without SSL
                CharacterSet = "utf8mb4"
            };

            var conn = new MySqlConnection(builder.ConnectionString);
            try
            {
                conn.Open();
                EnsureSchema(conn);
                conn.ChangeDatabase(Settings.Database);
                return conn;
            }
            catch (Exception ex)
            {
                conn.Dispose();
                throw new InvalidOperationException(
                    $"Cannot use MySQL ({Settings.User}@{Settings.Host}:{Settings.Port}, database '{Settings.Database}').\n" +
                    ex.Message +
                    "\nCheck that the MySQL server is running and that the user and password in dbsettings.json are correct.", ex);
            }
        }

        /// <summary>Creates the database and table if they do not exist yet (same as Database\elevator_db.sql).</summary>
        private void EnsureSchema(MySqlConnection conn)
        {
            lock (_schemaLock)
            {
                if (_schemaChecked) return;

                string db = Settings.Database.Replace("`", "``");
                RunDdl(conn, $"CREATE DATABASE IF NOT EXISTS `{db}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                conn.ChangeDatabase(Settings.Database);
                RunDdl(conn,
                    $@"CREATE TABLE IF NOT EXISTS {TableName} (
                        log_id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
                        elevator_name VARCHAR(20)  NOT NULL,
                        floor_no      TINYINT      NOT NULL,
                        status        VARCHAR(120) NOT NULL,
                        log_time      DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
                        PRIMARY KEY (log_id),
                        INDEX idx_log_time (log_time),
                        INDEX idx_log_elevator (elevator_name)
                    ) ENGINE=InnoDB");
                _schemaChecked = true;
            }
        }

        private static void RunDdl(MySqlConnection conn, string sql)
        {
            using var cmd = new MySqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
        }
    }
}
