namespace Elevator_Twin
{
    /// <summary>The colour scheme of the whole application (one theme: Pure White).</summary>
    public sealed class ThemeData
    {
        public string Name { get; init; }

        // ---- metal, accent, LED ----
        public Color[] Metal { get; init; }       // 5 gradient stops of the brushed dark-green metal
        public Color Led { get; init; }           // digits and text of the digital displays
        public Color Accent { get; init; }        // trims, lit buttons, door glow, title strip
        public Color CabTop { get; init; }        // cabin interior (top)
        public Color CabBottom { get; init; }     // cabin interior (bottom)

        // ---- backgrounds and text ----
        public Color FormBack { get; init; }      // window background
        public Color GridBack { get; init; }      // log grid
        public Color DisplayBack { get; init; }   // background of the digital displays
        public Color TextLight { get; init; }     // text on the dark background
        public Color Ink { get; init; }           // text on the dark metal (light)
        public Color CapInk { get; init; }        // dark text / arrows on the light silver call buttons
        public Color LitInk { get; init; }        // text of a lit button
        public Color DisabledInk { get; init; }   // text of a disabled button
        public Color DangerText { get; init; }    // red that stays readable as text on dark backgrounds

        // ---- cards and header ----
        public Color PanelTop { get; init; }      // lift control card (top)
        public Color PanelBottom { get; init; }   // lift control card (bottom)
        public Color PanelEdge { get; init; }     // card outline
        public Color HeaderTop { get; init; }     // header bar of the window
        public Color HeaderBottom { get; init; }

        // ---- building ----
        public Color StoneBase { get; init; }     // wall cladding: tile colour
        public Color StoneDark { get; init; }     // wall cladding: dark speckles / shadow
        public Color StoneLight { get; init; }    // wall cladding: light speckles / highlight
        public Color StoneJoint { get; init; }    // wall cladding: grout lines between the tiles
        public Color Landing { get; init; }       // tint of the stationary landing (floor) doors
        public Color HoistDark { get; init; }     // hoistway edge colour
        public Color HoistLight { get; init; }    // hoistway centre colour
        public Color FasciaTop { get; init; }     // machine-room fascia with the legend
        public Color FasciaBottom { get; init; }
        public Color FloorTop { get; init; }      // polished floor in front of the ground-floor doors
        public Color FloorBottom { get; init; }
        public Color PlinthTop { get; init; }     // slab next to the hoistway
        public Color PlinthBottom { get; init; }

        // ---- lamps ----
        public Color Ok { get; init; }            // green lamps / open doors
        public Color Danger { get; init; }        // red lamps (emergency, locked)
    }

    public static class Theme
    {
        public static ThemeData Current { get; } = new ThemeData
        {
            Name = "Pure White",

            Metal = new[]
            {
                Color.FromArgb(236, 240, 245), Color.FromArgb(255, 255, 255), Color.FromArgb(226, 231, 238),
                Color.FromArgb(246, 248, 251), Color.FromArgb(218, 224, 232)
            },
            Led = Color.FromArgb(0, 96, 148),                 // deep blue digits on white displays
            Accent = Color.FromArgb(224, 130, 0),             // amber / orange trims, lit buttons
            CabTop = Color.FromArgb(252, 253, 254),
            CabBottom = Color.FromArgb(172, 180, 192),

            FormBack = Color.FromArgb(255, 255, 255),
            GridBack = Color.FromArgb(255, 255, 255),
            DisplayBack = Color.FromArgb(255, 255, 255),
            TextLight = Color.FromArgb(31, 41, 55),
            Ink = Color.FromArgb(31, 41, 55),
            CapInk = Color.FromArgb(55, 65, 81),
            LitInk = Color.FromArgb(120, 60, 0),
            DisabledInk = Color.FromArgb(160, 168, 178),
            DangerText = Color.FromArgb(200, 30, 30),

            PanelTop = Color.FromArgb(255, 255, 255),
            PanelBottom = Color.FromArgb(246, 248, 251),
            PanelEdge = Color.FromArgb(208, 214, 223),
            HeaderTop = Color.FromArgb(255, 255, 255),
            HeaderBottom = Color.FromArgb(241, 244, 248),

            StoneBase = Color.FromArgb(238, 241, 245),
            StoneDark = Color.FromArgb(150, 158, 170),
            StoneLight = Color.FromArgb(255, 255, 255),
            StoneJoint = Color.FromArgb(196, 202, 212),
            Landing = Color.FromArgb(170, 182, 198),
            HoistDark = Color.FromArgb(176, 184, 196),
            HoistLight = Color.FromArgb(228, 232, 239),
            FasciaTop = Color.FromArgb(244, 246, 250),
            FasciaBottom = Color.FromArgb(214, 220, 229),
            FloorTop = Color.FromArgb(236, 239, 244),
            FloorBottom = Color.FromArgb(204, 210, 219),
            PlinthTop = Color.FromArgb(248, 249, 252),
            PlinthBottom = Color.FromArgb(218, 223, 231),

            Ok = Color.FromArgb(28, 160, 80),
            Danger = Color.FromArgb(214, 52, 52)
        };
    }
}
