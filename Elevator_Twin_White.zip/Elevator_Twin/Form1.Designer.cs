namespace Elevator_Twin
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            liftA = new LiftUnit();
            liftB = new LiftUnit();
            lblTitle = new Label();
            lblClock = new DisplayLabel();
            lblFilter = new Label();
            cboLogFilter = new ComboBox();
            btnLog = new SteelButton();
            btnClearLog = new SteelButton();
            btnExit = new SteelButton();
            dgvLog = new DataGridView();
            lblDbStatus = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvLog).BeginInit();
            SuspendLayout();
            // 
            // liftA
            // 
            liftA.Location = new Point(20, 66);
            liftA.Name = "liftA";
            liftA.Size = new Size(700, 520);
            liftA.TabIndex = 0;
            // 
            // liftB
            // 
            liftB.Location = new Point(760, 66);
            liftB.Name = "liftB";
            liftB.Size = new Size(700, 520);
            liftB.TabIndex = 1;
            // 
            // lblTitle
            // 
            lblTitle.BackColor = Color.Transparent;
            lblTitle.Font = new Font("Segoe UI Semibold", 17F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitle.ForeColor = Color.FromArgb(224, 130, 0);
            lblTitle.Location = new Point(18, 8);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(430, 40);
            lblTitle.TabIndex = 2;
            lblTitle.Text = "TWIN LIFT CONTROL ROOM";
            lblTitle.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblClock
            // 
            lblClock.BackColor = Color.FromArgb(255, 255, 255);
            lblClock.Font = new Font("Consolas", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblClock.ForeColor = Color.FromArgb(0, 96, 148);
            lblClock.Location = new Point(470, 10);
            lblClock.Name = "lblClock";
            lblClock.Size = new Size(300, 36);
            lblClock.TabIndex = 3;
            lblClock.Text = "00 Jan 0000  00:00:00";
            lblClock.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblFilter
            // 
            lblFilter.BackColor = Color.Transparent;
            lblFilter.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblFilter.ForeColor = Color.FromArgb(31, 41, 55);
            lblFilter.Location = new Point(800, 14);
            lblFilter.Name = "lblFilter";
            lblFilter.Size = new Size(48, 28);
            lblFilter.TabIndex = 4;
            lblFilter.Text = "LOG:";
            lblFilter.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // cboLogFilter
            // 
            cboLogFilter.BackColor = Color.FromArgb(255, 255, 255);
            cboLogFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            cboLogFilter.FlatStyle = FlatStyle.Flat;
            cboLogFilter.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cboLogFilter.ForeColor = Color.FromArgb(0, 96, 148);
            cboLogFilter.FormattingEnabled = true;
            cboLogFilter.Items.AddRange(new object[] { "All lifts", "Lift A", "Lift B" });
            cboLogFilter.Location = new Point(850, 14);
            cboLogFilter.Name = "cboLogFilter";
            cboLogFilter.Size = new Size(120, 28);
            cboLogFilter.TabIndex = 5;
            // 
            // btnLog
            // 
            btnLog.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLog.Location = new Point(990, 8);
            btnLog.Name = "btnLog";
            btnLog.Size = new Size(150, 40);
            btnLog.TabIndex = 6;
            btnLog.Text = "Show Log";
            // 
            // btnClearLog
            // 
            btnClearLog.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnClearLog.Location = new Point(1150, 8);
            btnClearLog.Name = "btnClearLog";
            btnClearLog.Size = new Size(150, 40);
            btnClearLog.TabIndex = 7;
            btnClearLog.Text = "Clear Log";
            // 
            // btnExit
            // 
            btnExit.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnExit.Location = new Point(1310, 8);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(150, 40);
            btnExit.TabIndex = 8;
            btnExit.Text = "Exit";
            // 
            // dgvLog
            // 
            dgvLog.AllowUserToAddRows = false;
            dgvLog.AllowUserToDeleteRows = false;
            dgvLog.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvLog.BorderStyle = BorderStyle.None;
            dgvLog.Location = new Point(20, 598);
            dgvLog.Name = "dgvLog";
            dgvLog.ReadOnly = true;
            dgvLog.RowHeadersVisible = false;
            dgvLog.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvLog.Size = new Size(1440, 154);
            dgvLog.TabIndex = 9;
            // 
            // lblDbStatus
            // 
            lblDbStatus.BackColor = Color.Transparent;
            lblDbStatus.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDbStatus.ForeColor = Color.FromArgb(31, 41, 55);
            lblDbStatus.Location = new Point(20, 758);
            lblDbStatus.Name = "lblDbStatus";
            lblDbStatus.Size = new Size(1440, 24);
            lblDbStatus.TabIndex = 10;
            lblDbStatus.Text = "Ready.";
            lblDbStatus.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            BackColor = Color.FromArgb(255, 255, 255);
            ClientSize = new Size(1480, 790);
            Controls.Add(liftA);
            Controls.Add(liftB);
            Controls.Add(lblTitle);
            Controls.Add(lblClock);
            Controls.Add(lblFilter);
            Controls.Add(cboLogFilter);
            Controls.Add(btnLog);
            Controls.Add(btnClearLog);
            Controls.Add(btnExit);
            Controls.Add(dgvLog);
            Controls.Add(lblDbStatus);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Twin Lift Control Room - Emerald";
            FormClosing += Form1_FormClosing;
            Load += Form1_Load;
            btnLog.Click += btnLog_Click;
            btnClearLog.Click += btnClearLog_Click;
            btnExit.Click += btnExit_Click;
            cboLogFilter.SelectedIndexChanged += cboLogFilter_SelectedIndexChanged;
            ((System.ComponentModel.ISupportInitialize)dgvLog).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private LiftUnit liftA;
        private LiftUnit liftB;
        private Label lblTitle;
        private DisplayLabel lblClock;
        private Label lblFilter;
        private ComboBox cboLogFilter;
        private SteelButton btnLog;
        private SteelButton btnClearLog;
        private SteelButton btnExit;
        private DataGridView dgvLog;
        private Label lblDbStatus;
    }
}
