namespace Elevator_Twin
{
    /// <summary>
    /// ONE complete lift: its own building shaft picture (cabin with inner door, fixed landing doors, call buttons),
    /// its own control panel and its own Elevator model with its own timer and state machine.
    /// The window hosts two of them (Lift A and Lift B), so every behaviour of the original lift exists twice and
    /// the two lifts never influence each other. Mirrored = true puts the panel on the right of the shaft.
    /// </summary>
    public partial class LiftUnit : UserControl, IElevatorObserver
    {
        private ElevatorController _controller;
        private Elevator _elevator;
        private bool _blink;                     // toggles every 250 ms (flashing alarm)
        private DateTime _lastBeep = DateTime.MinValue;
        private readonly SteelButton[] btnFloors;
        private readonly System.Windows.Forms.Timer _alarmTimer = new() { Interval = 250 };
        private static readonly TimeSpan AlarmDuration = TimeSpan.FromSeconds(6);

        private static readonly Color LampOff = Color.FromArgb(228, 232, 238);
        private static readonly Color LampOffText = Color.FromArgb(110, 118, 130);
        private static readonly Color Red = Color.FromArgb(214, 52, 52);

        /// <summary>The elevator model of this lift (null until Start was called).</summary>
        public Elevator Model => _elevator;

        /// <summary>When true the control panel is on the right of the shaft (used for the second lift).</summary>
        public bool Mirrored { get; set; }

        public LiftUnit()
        {
            InitializeComponent();
            DoubleBuffered = true;

            // settings the designer does not serialise (hidden custom-control properties)
            ledFloor.Caption = "FLOOR";
            btnFloors = new[] { btnFloorG, btnFloor1 };               // one button per floor, in floor order
            btnFloorG.Tag = Elevator.MinFloor;
            btnFloor1.Tag = Elevator.MaxFloor;
            btnEmergency.Tint = Theme.Current.Danger;
            btnEmergency.TextColor = Color.White;
            btnAlarm.Tint = Theme.Current.Accent;
            btnAlarm.TextColor = Color.Black;
            ApplyTheme();
        }

        /// <summary>Creates this lift's elevator, connects the displays and the database log and starts it.</summary>
        public void Start(string liftName, int startFloor, LogRepository repository)
        {
            ApplyMirror();
            lblTitle.Text = liftName.ToUpperInvariant();

            _elevator = new Elevator(liftName, startFloor);
            _controller = new ElevatorController(_elevator);
            shaft.Model = _elevator;                                   // the shaft draws exactly what the model says
            _elevator.Attach(this);                                    // GUI observer
            _elevator.Attach(new LogObserver(repository));             // database observer
            _elevator.PositionChanged += OnElevatorAnimated;           // delegates used for the animation
            _elevator.DoorsChanged += OnElevatorAnimated;
            shaft.CallRequested += Shaft_CallRequested;                // outside call buttons on the wall

            _alarmTimer.Tick += AlarmTimer_Tick;
            _alarmTimer.Start();

            RefreshView();
            _elevator.Notify("SYSTEM STARTED");
        }

        /// <summary>Stops the timers of this lift (called when the window closes).</summary>
        public void Shutdown()
        {
            _alarmTimer.Stop();
            _alarmTimer.Dispose();
            _elevator?.Dispose();
        }

        /// <summary>Swaps the two halves: shaft on the left, panel on the right.</summary>
        private void ApplyMirror()
        {
            if (!Mirrored) return;
            shaft.Left = 0;
            pnlPanel.Left = shaft.Width + 10;
        }

        // ---------------------------------------------------------- control panel buttons

        /// <summary>FLOOR buttons (G, 1): the floor number is stored in the button's Tag.</summary>
        private void btnFloor_Click(object sender, EventArgs e)
        {
            if (sender is Control c && c.Tag is int floor)
                SafeRun(() => _elevator.RequestFloor(floor));
        }

        private void btnUp_Click(object sender, EventArgs e) => SafeRun(_controller.GoUp);
        private void btnDown_Click(object sender, EventArgs e) => SafeRun(_controller.GoDown);
        private void btnOpenDoor_Click(object sender, EventArgs e) => SafeRun(_elevator.OpenDoors);
        private void btnCloseDoor_Click(object sender, EventArgs e) => SafeRun(_elevator.CloseDoors);
        private void btnEmergency_Click(object sender, EventArgs e) => SafeRun(_elevator.EmergencyStop);
        private void btnAlarm_Click(object sender, EventArgs e) => SafeRun(_elevator.RaiseAlarm);
        private void btnReset_Click(object sender, EventArgs e) => SafeRun(_elevator.Reset);
        private void btnLoadMinus_Click(object sender, EventArgs e) => SafeRun(() => _elevator.SetLoad(Math.Max(0, _elevator.Load - 100)));
        private void btnLoadPlus_Click(object sender, EventArgs e) => SafeRun(() => _elevator.SetLoad(_elevator.Load + 100));

        /// <summary>Outside call button: opens the door if the lift is already here, otherwise calls it to that floor.</summary>
        private void Shaft_CallRequested(int floor) => SafeRun(() => _elevator.RequestFloor(floor));

        private static void SafeRun(Action action)
        {
            try { action(); }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Elevator", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // ---------------------------------------------------------- alarm timeout and flashing

        private void AlarmTimer_Tick(object sender, EventArgs e)
        {
            _blink = !_blink;
            if (_elevator == null || !_elevator.AlarmActive) return;

            if (DateTime.Now - _elevator.AlarmStarted > AlarmDuration)
            {
                _elevator.ClearAlarm("ALARM STOPPED AUTOMATICALLY");
                return;
            }

            if ((DateTime.Now - _lastBeep).TotalMilliseconds > 1200)       // repeating alarm tone
            {
                _lastBeep = DateTime.Now;
                try { System.Media.SystemSounds.Exclamation.Play(); } catch { /* no sound device: ignore */ }
            }
            RefreshView();                                                  // flashing alarm indicators
        }

        // ---------------------------------------------------------- animation (delegate, every timer tick)

        private void OnElevatorAnimated(Elevator elevator) => RefreshView();

        // ---------------------------------------------------------- Observer callback

        public void OnElevatorEvent(Elevator elevator, string status) => RefreshView();

        private static Color DoorColor(Door door)
        {
            ThemeData t = Theme.Current;
            if (door == null) return t.Led;
            switch (door.State)
            {
                case DoorState.Open: return t.Ok;
                case DoorState.Opening:
                case DoorState.Closing: return t.Accent;
                default: return t.Led;
            }
        }

        /// <summary>Updates the shaft animation, the displays and the enabled state of every button.</summary>
        private void RefreshView()
        {
            Elevator el = _elevator;
            if (el == null) return;

            ThemeData t = Theme.Current;
            bool emergency = el.IsEmergency;
            bool moving = el.IsMoving;
            bool alarm = el.AlarmActive;
            bool overload = el.Overload;
            bool doorsClosed = el.AllDoorsClosed;          // inner door AND every landing door are shut
            string floor = Elevator.FloorName(el.CurrentFloor);
            int destination = el.DestinationFloor;
            string destinationText = destination == 0 ? "-" : Elevator.FloorName(destination);

            // --- animation: the cabin, its inner door and the landing door of every floor are drawn from the model
            shaft.Invalidate();

            // --- digital floor indicator and status display
            ledFloor.FloorText = floor;
            ledFloor.Direction = el.Direction;

            string direction = emergency ? "STOPPED"
                             : el.Direction > 0 ? "GOING UP \u2191"
                             : el.Direction < 0 ? "GOING DOWN \u2193" : "IDLE";
            string status = emergency ? "EMERGENCY STOP" : alarm ? "ALARM ACTIVE" : el.StatusText;

            lblCurrentFloor.Text = "Floor : " + floor;
            lblDestination.Text = "Dest  : " + destinationText;
            lblDirection.Text = "Dir   : " + direction;
            lblInnerDoor.Text = "Inner : " + el.Inner.Text;
            lblOuterDoor.Text = "Outer : " + el.OuterDoorText;
            lblDoor.Text = "Doors : " + el.DoorStateText;
            lblStatus.Text = "State : " + status;
            lblQueue.Text = "Queue : " + (el.Pending.Count == 0 ? "-" : string.Join(", ", el.Pending.Select(Elevator.FloorName)));

            lblInnerDoor.ForeColor = DoorColor(el.Inner);
            lblOuterDoor.ForeColor = DoorColor(el.ActiveOuterDoor);
            lblDoor.ForeColor = el.DoorStateText == "OPEN" ? DoorColor(el.Inner) : t.Led;
            lblStatus.ForeColor = emergency ? t.DangerText : alarm ? t.Accent : t.Led;

            // --- big message line
            string message;
            Color back = t.DisplayBack, fore = t.Led;
            if (emergency) { message = "EMERGENCY STOP"; back = Red; fore = Color.White; }
            else if (alarm) { message = "ALARM ACTIVATED"; back = _blink ? t.Accent : Red; fore = _blink ? Color.Black : Color.White; }
            else if (overload) { message = "OVERLOAD - REDUCE LOAD"; back = t.Accent; fore = Color.Black; }
            else if (moving) message = (el.Direction > 0 ? "GOING UP  \u2191  " : "GOING DOWN  \u2193  ") + destinationText;
            else if (el.StatusText == "READY") message = $"Floor: {floor}   IDLE";
            else message = el.StatusText;
            lblMessage.Text = message;
            lblMessage.BackColor = back;
            lblMessage.ForeColor = fore;

            // --- emergency / alarm / interlock indicators
            lblEmergencyLamp.BackColor = emergency ? Red : LampOff;
            lblEmergencyLamp.ForeColor = emergency ? Color.White : LampOffText;
            lblAlarmLamp.BackColor = alarm ? (_blink ? t.Accent : Red) : LampOff;
            lblAlarmLamp.ForeColor = alarm ? (_blink ? Color.Black : Color.White) : LampOffText;

            // interlock lamp: green = all doors closed and locked (movement allowed),
            //                 amber = a door is open or moving (movement inhibited), red = emergency stop
            if (emergency) { lblInterlockLamp.BackColor = Red; lblInterlockLamp.ForeColor = Color.White; }
            else if (!doorsClosed) { lblInterlockLamp.BackColor = t.Accent; lblInterlockLamp.ForeColor = Color.Black; }
            else { lblInterlockLamp.BackColor = Color.FromArgb(30, 140, 80); lblInterlockLamp.ForeColor = Color.White; }

            // --- cabin load (the overload sensor of the model)
            lblLoad.Text = $"LOAD {el.Load} / {Elevator.MaxLoadKg} kg";
            lblLoad.ForeColor = overload ? Color.Black : t.Led;
            lblLoad.BackColor = overload ? t.Accent : t.DisplayBack;
            btnLoadMinus.Enabled = !moving && el.Load > 0;
            btnLoadPlus.Enabled = !moving;

            // --- buttons: invalid controls are disabled automatically.
            //     Nothing at all in an emergency, and the elevator never moves (or accepts a floor from the panel)
            //     while the inner door or a landing door is not completely closed.
            bool canRequest = !emergency && doorsClosed;
            for (int i = 0; i < btnFloors.Length; i++)
            {
                int f = Elevator.MinFloor + i;
                bool here = el.IsAtFloor && el.CurrentFloor == f && !moving;
                btnFloors[i].Enabled = canRequest && !here && !el.IsRequested(f);
                btnFloors[i].Lit = el.IsRequested(f);
            }

            bool canTravel = canRequest && !moving;
            btnUp.Enabled = canTravel && el.NextFloorAbove <= Elevator.MaxFloor;       // no UP at the top floor
            btnDown.Enabled = canTravel && el.NextFloorBelow >= Elevator.MinFloor;     // no DOWN at the ground floor

            bool canDoor = !emergency && !moving && el.IsAtFloor;
            btnOpenDoor.Enabled = canDoor && !el.DoorTargetOpen;
            btnCloseDoor.Enabled = canDoor && el.DoorTargetOpen;

            btnEmergency.Enabled = !emergency;
            btnAlarm.Enabled = true;
            btnReset.Enabled = emergency || alarm;

            // lit buttons show what is happening
            btnUp.Lit = moving && el.Direction > 0;
            btnDown.Lit = moving && el.Direction < 0;
            btnEmergency.Lit = emergency;
            btnAlarm.Lit = alarm;
        }

        // ---------------------------------------------------------- theme

        private void ApplyTheme()
        {
            ThemeData t = Theme.Current;
            BackColor = t.FormBack;

            lblTitle.ForeColor = t.Accent;
            foreach (Label l in new[] { lblFloorCaption, lblMovementCaption, lblDoorCaption, lblSafetyCaption })
                l.ForeColor = t.Ink;
            foreach (Label l in new[] { lblCurrentFloor, lblDestination, lblDirection, lblInnerDoor, lblOuterDoor, lblDoor, lblStatus, lblQueue })
                l.ForeColor = t.Led;

            pnlInfo.BackColor = lblMessage.BackColor = lblLoad.BackColor = t.DisplayBack;
            lblMessage.ForeColor = t.Led;
            lblEmergencyLamp.BackColor = lblAlarmLamp.BackColor = lblInterlockLamp.BackColor = LampOff;
            lblEmergencyLamp.ForeColor = lblAlarmLamp.ForeColor = lblInterlockLamp.ForeColor = LampOffText;
        }
    }
}
